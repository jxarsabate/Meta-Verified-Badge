// Badge for Profile Name //
var v1checkTimer = 0;
function checkV1Code() {
  var v1Elements = document.querySelectorAll('h1.x1heor9g.x1qlqyl8.x1pd3egz.x1a2a7pz');
  for (var i = 0; i < v1Elements.length; i++) {
    var v1Element = v1Elements[i];
    if (!v1Element.querySelector('.v1-badge-check')) {
      v1Element.insertAdjacentHTML('beforeend', '<span style="margin-left: 6px;" class="xt0psk2 v1-badge-check"><div aria-label="Verified" class="x1i10hfl x1qjc9v5 xjbqb8w xjqpnuy xa49m3k xqeqjp1 x2hbi6w x13fuv20 xu3j5b3 x1q0q8m5 x26u7qi x972fbf xcfux6l x1qhh985 xm0m39n x9f619 xdl72j9 x2lah0s xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r x2lwn1j xeuugli xexx8yu x4uap5 x18d9i69 xkhd6sd x1n2onr6 x16tdsg8 x1hl2dhg xggy1nq x1ja2u2z x1t137rt x1o1ewxj x3x9cwd x1e5q0jg x13rtm0m x3nfvp2 x1q0g3np x87ps6o x1lku1pv xt0e3qv x1a2a7pz" role="button" tabindex="0"><span class="x3nfvp2 x11njtxf"><svg fill="currentColor" viewBox="0 0 12 13" width="1em" height="1em" class="x1lliihq x1k90msu x2h7rmj x1qfuztq x1qq9wsj xlup9mm x1kky2od" title="Verified account"><g fill-rule="evenodd" transform="translate(-98 -917)"><path d="m106.853 922.354-3.5 3.5a.499.499 0 0 1-.706 0l-1.5-1.5a.5.5 0 1 1 .706-.708l1.147 1.147 3.147-3.147a.5.5 0 1 1 .706.708m3.078 2.295-.589-1.149.588-1.15a.633.633 0 0 0-.219-.82l-1.085-.7-.065-1.287a.627.627 0 0 0-.6-.603l-1.29-.066-.703-1.087a.636.636 0 0 0-.82-.217l-1.148.588-1.15-.588a.631.631 0 0 0-.82.22l-.701 1.085-1.289.065a.626.626 0 0 0-.6.6l-.066 1.29-1.088.702a.634.634 0 0 0-.216.82l.588 1.149-.588 1.15a.632.632 0 0 0 .219.819l1.085.701.065 1.286c.014.33.274.59.6.604l1.29.065.703 1.088c.177.27.53.362.82.216l1.148-.588 1.15.589a.629.629 0 0 0 .82-.22l.701-1.085 1.286-.064a.627.627 0 0 0 .604-.601l.065-1.29 1.088-.703a.633.633 0 0 0 .216-.819"></path></g></svg></span><div class="x1ey2m1c xds687c xg01cxk x47corl x10l6tqk x17qophe x13vifvy x1ebt8du x19991ni x1dhq9h x1wpzbip x14yjl9h xudhj91 x18nykt9 xww2gxu" data-visualcompletion="ignore"></div></div></span>');
    }
  }
  if (v1checkTimer < 60) {
    v1checkTimer += 1;
    setTimeout(checkV1Code, 100);
  }
}
setTimeout(checkV1Code, 100);


// Badge for Sticky Name //
var v2checkTimer = 0;
function checkV2Code() {
  var v2Elements = document.querySelectorAll('span.x1lliihq.x6ikm8r.x10wlt62.x1n2onr6.xlyipyv.xuxw1ft.x1j85h84');
  for (var i = 0; i < v2Elements.length; i++) {
    var v2Element = v2Elements[i];
    if (!v2Element.querySelector('.v2-badge-check')) {
      v2Element.insertAdjacentHTML('beforeend', '<span class="v2-badge-check x3nfvp2 x11njtxf"><span class="x1dor1uw x1n2onr6">&nbsp;<span><span class="x3nfvp2 x11njtxf"><svg fill="currentColor" viewBox="0 0 12 13" width="1em" height="1em" class="x1lliihq x1k90msu x2h7rmj x1qfuztq x1qq9wsj x1kpxq89 xsmyaan" title="Verified account"><g fill-rule="evenodd" transform="translate(-98 -917)"><path d="m106.853 922.354-3.5 3.5a.499.499 0 0 1-.706 0l-1.5-1.5a.5.5 0 1 1 .706-.708l1.147 1.147 3.147-3.147a.5.5 0 1 1 .706.708m3.078 2.295-.589-1.149.588-1.15a.633.633 0 0 0-.219-.82l-1.085-.7-.065-1.287a.627.627 0 0 0-.6-.603l-1.29-.066-.703-1.087a.636.636 0 0 0-.82-.217l-1.148.588-1.15-.588a.631.631 0 0 0-.82.22l-.701 1.085-1.289.065a.626.626 0 0 0-.6.6l-.066 1.29-1.088.702a.634.634 0 0 0-.216.82l.588 1.149-.588 1.15a.632.632 0 0 0 .219.819l1.085.701.065 1.286c.014.33.274.59.6.604l1.29.065.703 1.088c.177.27.53.362.82.216l1.148-.588 1.15.589a.629.629 0 0 0 .82-.22l.701-1.085 1.286-.064a.627.627 0 0 0 .604-.601l.065-1.29 1.088-.703a.633.633 0 0 0 .216-.819"></path></g></svg></span></span></span></span>');
    }
  }
  if (v2checkTimer < 60) {
    v2checkTimer += 1;
    setTimeout(checkV2Code, 100);
  }
}
setTimeout(checkV2Code, 100);


// Badge for Timeline Name //
var v3checkTimer = 0;
function checkV3Code() {
  var v3Elements = document.querySelectorAll('h2.x1heor9g.x1qlqyl8.x1pd3egz.x1a2a7pz.x1gslohp.x1yc453h');
  for (var i = 0; i < v3Elements.length; i++) {
    var v3Element = v3Elements[i];
    var strongElement = v3Element.querySelector('strong');
    var spanElement = v3Element.querySelector('span');
    if (strongElement && spanElement && !v3Element.querySelector('.v3-badge-check')) {
      v3Element.insertAdjacentHTML('beforeend', '<span class="v3-badge-check x3nfvp2 x11njtxf"><span class="x1dor1uw x1n2onr6">&nbsp;<span><span class="x3nfvp2 x11njtxf"><svg fill="currentColor" viewBox="0 0 12 13" width="1em" height="1em" class="x1lliihq x1k90msu x2h7rmj x1qfuztq x1qq9wsj x1kpxq89 xsmyaan" title="Verified account"><g fill-rule="evenodd" transform="translate(-98 -917)"><path d="m106.853 922.354-3.5 3.5a.499.499 0 0 1-.706 0l-1.5-1.5a.5.5 0 1 1 .706-.708l1.147 1.147 3.147-3.147a.5.5 0 1 1 .706.708m3.078 2.295-.589-1.149.588-1.15a.633.633 0 0 0-.219-.82l-1.085-.7-.065-1.287a.627.627 0 0 0-.6-.603l-1.29-.066-.703-1.087a.636.636 0 0 0-.82-.217l-1.148.588-1.15-.588a.631.631 0 0 0-.82.22l-.701 1.085-1.289.065a.626.626 0 0 0-.6.6l-.066 1.29-1.088.702a.634.634 0 0 0-.216.82l.588 1.149-.588 1.15a.632.632 0 0 0 .219.819l1.085.701.065 1.286c.014.33.274.59.6.604l1.29.065.703 1.088c.177.27.53.362.82.216l1.148-.588 1.15.589a.629.629 0 0 0 .82-.22l.701-1.085 1.286-.064a.627.627 0 0 0 .604-.601l.065-1.29 1.088-.703a.633.633 0 0 0 .216-.819"></path></g></svg></span></span></span></span></span></span>');
    }
  }
  if (v3checkTimer < 60) {
    v3checkTimer += 1;
    setTimeout(checkV3Code, 100);
  }
}
setTimeout(checkV3Code, 100);