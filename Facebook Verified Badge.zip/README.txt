Installations:
----------------------

1. Download the Facebook Verified Badge Chrome Extension from our site.

2. Extract the downloaded file to your preferred location.

3. Open your Chrome browser and go to the “Extensions” tab by clicking on the three dots in the top right corner of the browser, then select “More tools” and “Extensions”.

4. Enable “Developer mode” by toggling the button in the top right corner of the “Extensions” page.

5. Click on the “Load unpacked” button in the top left corner of the page.

6. Navigate to the extracted Facebook Badge folder and select it.

7. The Facebook Badge Chrome Extension will now be added to your Chrome browser and ready to use.


Great, Now simply visit your Facebook profile to see if the badge has appeared.


NOTE: It’s a fun tool that allows you to add a verified badge to your Facebook profile, but it is not an official Facebook feature. Only the current user of the extension will be able to see the badge, and it is not visible to anyone else.